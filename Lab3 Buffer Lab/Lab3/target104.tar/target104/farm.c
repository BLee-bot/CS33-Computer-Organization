/* This function marks the start of the farm */
int start_farm()
{
    return 1;
}

void setval_123(unsigned *p)
{
    *p = 3284633928U;
}

unsigned getval_140()
{
    return 3277389668U;
}

void setval_295(unsigned *p)
{
    *p = 2421686321U;
}

void setval_343(unsigned *p)
{
    *p = 3284633928U;
}

unsigned addval_490(unsigned x)
{
    return x + 3284633930U;
}

unsigned addval_248(unsigned x)
{
    return x + 3281031240U;
}

unsigned getval_194()
{
    return 3281293400U;
}

unsigned getval_379()
{
    return 3251079496U;
}

/* This function marks the middle of the farm */
int mid_farm()
{
    return 1;
}

/* Add two arguments */
long add_xy(long x, long y)
{
    return x+y;
}

void setval_317(unsigned *p)
{
    *p = 3229926029U;
}

unsigned getval_149()
{
    return 3281179017U;
}

unsigned getval_232()
{
    return 2425541001U;
}

unsigned getval_122()
{
    return 3374367369U;
}

void setval_209(unsigned *p)
{
    *p = 3469327134U;
}

unsigned getval_182()
{
    return 2428666343U;
}

unsigned addval_474(unsigned x)
{
    return x + 3281044105U;
}

unsigned getval_488()
{
    return 2425541001U;
}

unsigned getval_378()
{
    return 3286272328U;
}

unsigned getval_399()
{
    return 2447411528U;
}

unsigned addval_280(unsigned x)
{
    return x + 3536110217U;
}

void setval_205(unsigned *p)
{
    *p = 3286272328U;
}

unsigned addval_422(unsigned x)
{
    return x + 3232026249U;
}

unsigned addval_131(unsigned x)
{
    return x + 2428676604U;
}

void setval_150(unsigned *p)
{
    *p = 3224948377U;
}

void setval_367(unsigned *p)
{
    *p = 2430634328U;
}

unsigned addval_281(unsigned x)
{
    return x + 3766569200U;
}

void setval_441(unsigned *p)
{
    *p = 3674788233U;
}

void setval_100(unsigned *p)
{
    *p = 3286272456U;
}

unsigned addval_109(unsigned x)
{
    return x + 3247493513U;
}

unsigned addval_402(unsigned x)
{
    return x + 3269495112U;
}

unsigned addval_259(unsigned x)
{
    return x + 3525886601U;
}

unsigned addval_102(unsigned x)
{
    return x + 3531919745U;
}

void setval_360(unsigned *p)
{
    *p = 3525362312U;
}

void setval_338(unsigned *p)
{
    *p = 3353381192U;
}

void setval_492(unsigned *p)
{
    *p = 4140289673U;
}

unsigned getval_414()
{
    return 2613301673U;
}

void setval_121(unsigned *p)
{
    *p = 3677933192U;
}

unsigned addval_442(unsigned x)
{
    return x + 2425409929U;
}

unsigned getval_391()
{
    return 3674263177U;
}

unsigned addval_466(unsigned x)
{
    return x + 3281047177U;
}

unsigned getval_287()
{
    return 2429454721U;
}

/* This function marks the end of the farm */
int end_farm()
{
    return 1;
}
